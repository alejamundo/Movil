import React from "react";
import user from '../img/user.png'


function Navbar() {
  return (
    <div >
      <div className="col-span-5">
        <header className="flex flex-col md:flex-row gap-4  p-4 md:px-8 lg:px-12 w-full">
          <nav className="w-full md:[60%] lg:w-[70%] flex items-center md:justify-end">
            <img className="relative" src={user} alt="user" width={'5%'}/>
            <h6 className="font-semibold p-2">Administrador PowerFit </h6> 
          </nav>
        </header>
      </div>
    </div>
  );
}

export default Navbar;
