// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC8Lz0T0fuppMprFvyIKoa2Ao8eNYqGyxQ",
  authDomain: "gymaleja-640ba.firebaseapp.com",
  projectId: "gymaleja-640ba",
  storageBucket: "gymaleja-640ba.appspot.com",
  messagingSenderId: "551189760069",
  appId: "1:551189760069:web:8bdf4aadea43015143fb2c",
  measurementId: "G-XEFXT236W0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export default firebaseConfig;