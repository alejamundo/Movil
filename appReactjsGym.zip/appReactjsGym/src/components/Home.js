import React from "react";
import { FaDumbbell, FaRunning, FaBicycle } from 'react-icons/fa';
import banner from '../img/banner.jpg'

function Home() {
  return (
    <div> 
      <div className="col-span-5">
        <div className="  p-4 bg-gray-100">
        <section className="rounded-lg bg-center bg-no-repeat bg-cover bg-gray-700 bg-blend-multiply h-80" style={{ backgroundImage: `url(${banner})` }}>
        <div className="p-6 mx-auto max-w-screen-xl text-center ">
            <h1 className="mb-7 font-extrabold tracking-tight leading-none text-white text-2xl md:text-4xl"> ¡Descubre todo lo que puedes lograr!</h1>
            <p className="mb-8 text-lg font-normal text-gray-300 lg:text-xl sm:px-16 lg:px-48">"PowerFit: Tu destino para la fuerza y el bienestar. Enfócate en tu fitness con nuestras instalaciones de vanguardia, entrenadores calificados y una comunidad de apoyo."</p>
        </div>
        </section>
        <h1 className="font-semibold text-center text-lg mt-5 mb-5">Metodologia</h1> 
         <div 
            className="bg-white rounded-2xl p-8 flex flex-col md:flex-row gap-8 w-full drop-shadow-lg border-2 border-transparent hover:border-purple-400 transition-all mb-4"
          >
            <div className="w-full md:w-[10%] flex items-center justify-start md:justify-center">
              <FaDumbbell className="text-7xl bg-purple-100 text-purple-600 p-4 rounded-md" />
            </div>
            <div className="w-full md:w-[70%]">
              <h1 className="text-xl flex items-center gap-4 mb-2">
              Desafíos Mensuales
                <span className="text-xs py-1 px-2 bg-purple-100 text-purple-600 font-bold">
                  Cardio
                </span>
                <span className="text-xs py-1 px-2 bg-green-100 text-green-600 font-bold">
                  Fuerza
                </span>
              </h1>
            </div>
            <p className="text-gray-500 text-justify">PowerFit organiza desafíos mensuales en los que los miembros compiten en diferentes categorías, como pérdida de peso, aumento de fuerza o superación de obstáculos. Los miembros que alcanzan metas específicas podrían recibir premios o reconocimientos especiales, lo que fomenta la motivación y el compromiso.</p>
            <div className="w-full md:w-[20%] flex flex-col items-end">
              <h3 className="text-xl text-gray-500 mb-2">Pierde hasta 10 Kg</h3>
              <p className="text-gray-500">30 dias</p>
            </div>
          </div>
          <div
            href="s"
            className="bg-white rounded-2xl p-8 flex flex-col md:flex-row gap-8 w-full drop-shadow-lg border-2 border-transparent hover:border-purple-400 transition-all mb-4"
          >
            <div className="w-full md:w-[10%] flex items-center justify-start md:justify-center">
              <FaRunning  className="text-7xl bg-purple-100 text-purple-600 p-4 rounded-md" />
            </div>
            <div className="w-full md:w-[70%]">
              <h1 className="text-xl flex items-center gap-4 mb-2">
              Entrenamiento de Resistencia
                <span className="text-xs py-1 px-2 bg-purple-100 text-purple-600 font-bold">
                  Cardio
                </span>
              </h1>   
            </div>
            <p className="text-gray-500 text-justify">PowerFit ofrece un programa de entrenamiento de resistencia, que se enfoca en el uso de bandas elásticas, pesas rusas y otras herramientas para fortalecer y tonificar el cuerpo. Este tipo de entrenamiento es efectivo para desarrollar la fuerza muscular y la estabilidad.</p>
            <div className="w-full md:w-[20%] flex flex-col items-end">
              <h3 className="text-xl text-gray-500 mb-2">Pierde hasta 1 Kg</h3>
              <p className="text-gray-500">15 dias</p>
            </div>
          </div>
          <div
            href="s"
            className="bg-white rounded-2xl p-8 flex flex-col md:flex-row gap-8 w-full drop-shadow-lg border-2 border-transparent hover:border-purple-400 transition-all mb-4"
          >
            <div className="w-full md:w-[10%] flex items-center justify-start md:justify-center">
              <FaBicycle  className="text-7xl bg-purple-100 text-purple-600 p-4 rounded-md" />
            </div>
            <div className="w-full md:w-[70%]">
              <h1 className="text-xl flex items-center gap-4 mb-2">
              Entrenamiento al Aire Libre          
                <span className="text-xs py-1 px-2 bg-yellow-100 text-yellow-600 font-bold">
                  Fexibilidad
                </span>
              </h1>     
            </div>
            <p className="text-gray-500 text-justify">PowerFit organiza sesiones de entrenamiento al aire libre en parques locales, playas o espacios abiertos. Estas sesiones podrían incluir ejercicios que aprovechen el entorno natural, como carreras en la playa, ejercicios de escalada en roca o circuitos en parques. </p>
            <div className="w-full md:w-[20%] flex flex-col items-end">
              <h3 className="text-xl text-gray-500 mb-2">Pierde hasta 5 Kg</h3>
              <p className="text-gray-500">30 dias</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
