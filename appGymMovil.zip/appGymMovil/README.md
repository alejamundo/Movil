# App Movil GYm ApowerFit React Native Expo and Firebase

Gym ApowerFit es una aplicación móvil desarrollada con React Native Expo y Firebase que te permite llevar un registro de tus entrenamientos, cancelar clases y obserbar tus rutinas.