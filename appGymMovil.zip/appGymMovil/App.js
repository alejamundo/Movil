import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import logo from './assets/gym.png';
import { View,Image } from "react-native";
import Login from "./components/Login";
import Home from "./components/Home";
import Index from "./components/Index";
import Reserve from "./components/Reserve";

const Stack = createStackNavigator();

export default function App() {
  // Configuración de la navegación de la app
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Index"
        screenOptions={{
          headerTitle: "PowerFit",
          headerTitleStyle: {
            fontWeight: "bold",
            fontSize: 24,
          },
          headerTitleAlign: "center",
          headerLeft: () => (
            <Image
              source={ logo } 
              style={{ width: 60, height: 40, marginLeft: 10 }}
            />
          ),
         
        }}
        
      >
        <Stack.Screen name="Index" component={Index} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Reserve" component={Reserve} />
     
      </Stack.Navigator>
    </NavigationContainer>
  );
}
