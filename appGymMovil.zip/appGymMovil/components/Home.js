import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { FontAwesome5 } from "@expo/vector-icons";
import { db } from "../config/firebase";
import {
  collection,
  query,
  where,
  getDocs,
  updateDoc,
  doc,
} from "firebase/firestore";
import { useFocusEffect } from "@react-navigation/native";
const imgTraining = require("../assets/training.jpg");

const Home = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const userId = route.params?.userId;

  const [assignedData, setAssignedData] = useState([]);

  // Función para obtener datos de "assigned" y relacionarlos con "training"
  const getData = async (userId) => {
    try {
      const assignedCollection = collection(db, "assigned");
      const q = query(assignedCollection, where("userId", "==", userId));
      const querySnapshot = await getDocs(q);

      const assignedData = [];
      for (const doc of querySnapshot.docs) {
        const data = doc.data();
        const trainingId = data.trainingId;

        const trainingCollection = collection(db, "training");
        const trainingQuery = query(trainingCollection);
        const trainingQuerySnapshot = await getDocs(trainingQuery);

        trainingQuerySnapshot.forEach((trainingDoc) => {
          // Obtiene los datos de entrenamiento
          const trainingData = trainingDoc.data();

          // Compara el ID del entrenamiento en "assigned" con el ID en "training"
          if (trainingId === trainingDoc.id) {
            // Agrega los datos de entrenamiento a la estructura de datos de assigned
            data.trainingData = trainingData;
          }
        });

        assignedData.push(data);
      }
      return assignedData;
    } catch (e) {
      console.error("Error al obtener datos de la tabla 'assigned':", e);
      return [];
    }
  };

  const reservation = async (assignment) => {
    console.log(assignment.trainingId);
    if (!assignment || typeof assignment !== "object") {
      console.error("El objeto pasado es invalido:", assignment);
      return;
    }

    try {
      const trainingId = assignment.trainingId;
      const trainingCollection = collection(db, "training");
      const assignedDocRef = doc(db, "training", trainingId);

      await updateDoc(assignedDocRef, { isReserve: true });
      Alert.alert("Reserva exitosa", "Es hora de entrenar");

      getData(userId)
        .then((data) => {
          setAssignedData(data);
        })
        .catch((e) => {
          console.error("Error al obtener los registros de la tabla :", e);
        });
    } catch (e) {
      console.error("Error al reservar :", e);
    }
  };
  
  useFocusEffect(
    React.useCallback(() => {
      if (userId) {
        getData(userId)
          .then((data) => {
            setAssignedData(data);
          })
          .catch((e) => {
            console.error("Error al obtener los registros :", e);
          });
      }
    }, [userId])
  );

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={{ fontSize: 25, margin: 10, color: "#7E3AF2" }}>
          Entrenamientos
        </Text>
        <Image
          source={imgTraining}
          alt="img trainig"
          style={styles.backImage}
        ></Image>

        {assignedData.map((assignment, index) => (
          <View key={index} style={styles.assignmentCard}>
            <View style={styles.textContainer}>
              <Text style={styles.cardText}>
                <FontAwesome5 name="book" size={18} color="black" /> Categoría:
                {assignment.trainingData.category}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="calendar" size={18} color="black" /> Día:
                {assignment.trainingData.day}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="info-circle" size={18} color="black" />
                Descripción: {assignment.trainingData.description}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="user" size={18} color="black" /> Nombre:
                {assignment.trainingData.name}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="clock" size={18} color="black" /> Hora de
                inicio: {assignment.trainingData.startHour}
              </Text>

              {assignment.trainingData.isReserve ? (
                <Pressable onPress={() => Alert.alert('Rutina ya reservada',':)')}>
                  <View style={styles.btn}>
                    <Text style={{ color: "white" }}>
                      {assignment.trainingData.isReserve
                        ? "Agendado"
                        : "Reservar"}
                    </Text>
                  </View>
                </Pressable>
              ) : (
                <Pressable onPress={() => reservation(assignment)}>
                  <View style={styles.btn}>
                    <Text style={{ color: "white" }}>
                      {assignment.trainingData.isReserve
                        ? "Agendado"
                        : "Reservar"}
                    </Text>
                  </View>
                </Pressable>
              )}
             

              <Pressable
                onPress={() =>
                  navigation.navigate("Reserve", {
                    reservasData: assignedData,
                  })
                }
              >
                <View style={styles.btn}>
                  <Text style={{ color: "white" }}>Ver mis Rutinas</Text>
                </View>
              </Pressable>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  assignmentCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "lavender",
    padding: 10,
    margin: 10,
    borderRadius: 30,
    padding: 20,
  },
  iconContainer: {
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  cardText: {
    fontSize: 16,
    marginBottom: 5,
  },
  backImage: {
    width: "100%",
    height: 200,
    position: "relative",
    top: 0,
    resizeMode: "cover",
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
  btn: {
    width: "100%",
    height: 50,
    margin: 5,
    backgroundColor: "#7E3AF2",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
});
