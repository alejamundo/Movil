import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Alert,
  Image,
} from "react-native";
import { useRoute } from "@react-navigation/native";
import {
  collection,
  query,
  where,
  getDocs,
  updateDoc,
  doc,
} from "firebase/firestore";
import { db } from "../config/firebase";
const imgTraining = require("../assets/training.jpg");

const Reserve = () => {
  const route = useRoute();
  const reserveData = route.params?.reservasData;

  const [reserve, setReserve] = useState([]);

  useEffect(() => {
    const reserveFilter = reserveData.filter(
      (assignment) => assignment.trainingData.isReserve
    );
    setReserve(reserveFilter);
  }, [reserveData]);

  const notReservation = async (assignment) => {
    Alert.alert("Cancelando..... reserva", "Que triste :(");

    if (!assignment || typeof assignment !== "object") {
      console.error("Invalido:", assignment);
      return;
    }

    try {
      const trainingId = assignment.trainingId;
      console.log("Training ID:", trainingId);

      const trainingCollection = collection(db, "training");
      console.log("collecion:", trainingId);
      const assignedDocRef = doc(db, "training", trainingId);

      await updateDoc(assignedDocRef, { isReserve: false });
      
      const querySnapshot = await getDocs(
        query(trainingCollection, where("isReserve", "==", true))
      );
      const updatedReserve = querySnapshot.docs.map((doc) => doc.data());
      setReserve(updatedReserve);
    } catch (e) {
      Alert.alert("Error al cancelar la reserva:", "Fallas");
    }
  };

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={{ fontSize: 25, margin: 10, color: "#7E3AF2" }}>
          Mis Entrenamientos
        </Text>
        <Image
          source={imgTraining}
          alt="img trainig"
          style={styles.backImage}
        ></Image>

        {reserve.map((assignment, index) => (
          <View key={index} style={styles.assignmentCard}>
            <View style={styles.textContainer}>
              <Text style={styles.cardText}>
                Categoría:{" "}
                {assignment.trainingData && assignment.trainingData.category}
              </Text>
              <Text style={styles.cardText}>
                Día: {assignment.trainingData && assignment.trainingData.day}
              </Text>
              <Text style={styles.cardText}>
                Descripción:{" "}
                {assignment.trainingData && assignment.trainingData.description}
              </Text>
              <Text style={styles.cardText}>
                Nombre:{" "}
                {assignment.trainingData && assignment.trainingData.name}
              </Text>
              <Text style={styles.cardText}>
                Hora de inicio:{" "}
                {assignment.trainingData && assignment.trainingData.startHour}
              </Text>
              <Pressable onPress={() => notReservation(assignment)}>
                <View style={styles.btn}>
                  <Text style={{ color: "black", fontWeight: "bold" }}>
                    Cancelar Rutina
                  </Text>
                </View>
              </Pressable>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

export default Reserve;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  assignmentCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "lavender",
    padding: 10,
    margin: 10,
    borderRadius: 30,
    padding: 20,
  },
  iconContainer: {
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  cardText: {
    fontSize: 16,
    marginBottom: 5,
  },
  backImage: {
    width: "100%",
    height: 200,
    position: "relative",
    top: 0,
    resizeMode: "cover",
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
  btn: {
    width: "100%",
    height: 50,
    margin: 5,
    backgroundColor: "#FF9700",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
});
