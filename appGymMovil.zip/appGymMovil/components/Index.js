import React from "react";
import {
  StatusBar,
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  Pressable,
} from "react-native";

const Index = ({ navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
      <Image source={require("../assets/training.jpg")} style={style.image} />
      <View style={{ paddingHorizontal: 20, paddingTop: 20 }}>
        <View>
          <Text style={style.title}>PowerFit</Text>
          <Text style={style.title}>Entrena con los mejores</Text>
        </View>

        <View style={{ marginTop: 10 }}>
          <Text style={style.textStyle}>
            Ingresa, y revisa tus rutinas , reseva y mucho más
          </Text>
        </View>
      </View>
      <View
        style={{
          flex: 1,
          justifyContent: "flex-end",
          paddingBottom: 40,
        }}
      >
        <Pressable onPress={() => navigation.navigate("Login")}>
          <View style={style.btn}>
            <Text style={{ color: "white", fontSize: 20 }}>Log In</Text>
          </View>
        </Pressable>
      </View>
    </SafeAreaView>
  );
};

export default Index;

const style = StyleSheet.create({
  image: {
    height: 420,
    width: "100%",
    borderBottomLeftRadius: 100,
  },

  btn: {
    height: 60,
    marginHorizontal: 20,
    backgroundColor: "#7E3AF2",
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
  },
  textStyle: {
    fontSize: 16,
    color: "gray",
  },
});
