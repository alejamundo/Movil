import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Firebase config
const firebaseConfig = {
 apiKey: "AIzaSyDEWLSh5jACAOOjX3XXAdNvrhkUFFUUdq4",
  authDomain: "appgym-3e346.firebaseapp.com",
  projectId: "appgym-3e346",
  storageBucket: "appgym-3e346.appspot.com",
  messagingSenderId: "1098356614786",
  appId: "1:1098356614786:web:dca241e6330fdcd6ef769b",
  measurementId: "G-5BXS9RFSP7"
};
// initialize firebase
initializeApp(firebaseConfig);
export const db = getFirestore();
