import { StatusBar } from 'expo-status-bar';
import { SafeAreaView, ScrollView, StyleSheet, Text, View, Pressable, Image, Alert, Modal } from 'react-native';
import React, { useState } from 'react';
import imgInicio from './assets/principal.png';
import Form from './src/components/Form';
import Paciente from './src/components/Paciente';

export default function App() {

  //hooks
  const [modal, setModal] = useState(false);
  const [pacientes,setPacientes]=useState([]);
  //manejadores
  const handleNuevaCita = () => {
    console.log('Nueva cita');
  }
  const handleVisible = () => {
    setModal(true);
  }


  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.viewPrincipal}>
          <Text style={styles.titulo}>Administración de citas</Text>
          <Text style={styles.subtitilo}>Veterinaria</Text>
          <Pressable
            style={styles.btn}
            onPress={handleVisible}>
            <Text style={styles.btnText}>Nueva Cita</Text>
          </Pressable>
          <Image source={imgInicio}></Image>
          <Modal
            animationType='slide'
            visible={modal}>
            <Form
              modal={modal} />
          </Modal>
          <StatusBar style="auto" />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgb(63,94,251)',
    marginTop: 30,
    paddingTop: 50,
    flex: 1
  },
  titulo: {
    fontSize: 30,
    fontFamily: 'sans-serif',
    fontStyle: 'italic',
    color:'white',
  },
  subtitilo: {
    fontSize: 30,
    fontStyle: 'italic',
    paddingBottom: 30,
    color:'white',
  },
  viewPrincipal: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn: {
    backgroundColor: '#fff',
    padding: 15,
    marginTop: 30,
    marginBottom: 20,
    marginHorizontal: 20,
    borderRadius: 10,
  },
  btnText: {
    textAlign: 'center',

  },
});
