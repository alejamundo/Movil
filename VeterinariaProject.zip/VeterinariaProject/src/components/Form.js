import React, { useState } from "react";
import {
    SafeAreaView, Text, TextInput, ScrollView,
    Pressable, StyleSheet, View, Alert,Image
} from 'react-native';
import imgInicio from '../components/src/assets/principal.png';

function Form() {

    const [paciente, setPaciente] = useState('');
    const [propietario, setPropietario] = useState('');
    const [telefono, setTelefono] = useState('');
    const [email, setEmail] = useState('');
    const [sintomas, setSintomas] = useState('');
    const [fechaalta, setFechaAlta] = useState(new Date());
    const [modal, setModal] = useState(false);
    const handleVisible = () => {
        setModal(false);
    }

    const handleCita = () => {
        if ([paciente, propietario, email].includes('')) {
            Alert.alert(
                'Error',
                'Todos los campop son obligatorios',
            )
            return
        }
        //revisa si es oibjeto nuevo o edicioon
        const newPaciente = {
            id: new Date(),
            paciente,
            propietario,
            email,
            telefono,
            fechaalta,
            sintomas
        }
        //cerra modal
        //limpiar campos
        //enviasr opbejto sin borrar lo que ya tenemos
    }



    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>
                <View >
                    <Text style={styles.titulo}>
                        Asignación de nueva cita
                    </Text>
                    <Image source={imgInicio}></Image>
                    <View style={{marginLeft:100, paddingTop:30}}>
                        <Text style={styles.texto}>
                            Ingrese nombre *
                        </Text>
                        <TextInput
                            placeholder="Nombre paciente"
                            value={paciente}
                            onChangeText={setPaciente}

                        />

                        <Text style={styles.texto}>
                            Propietario
                        </Text>
                        <TextInput
                            placeholder="Propietario"
                            value={paciente}
                            onChangeText={setPropietario}
                        />

                        <Text style={styles.texto}>
                            Telefono
                        </Text>
                        <TextInput
                            placeholder="telefono"
                            value={telefono}
                            onChangeText={setTelefono}
                            keyboardType="number-pad"
                            maxLength={10} />

                        <Text style={styles.texto}>
                            email
                        </Text>
                        <TextInput
                            placeholder="Email"
                            value={email}
                            onChangeText={setEmail}
                            keyboardType="email-address"
                        />
                        <Text style={styles.texto}>
                            Fecha de alta
                        </Text>
                        {/* <View>
                        <DateTimePickerModal
                            isVisible={DatePickerMostrar}
                            mode="date"
                            

                        />
                    </View> */}


                        <Text style={styles.texto}>
                            Sintomas
                        </Text>
                        <TextInput
                            placeholder="Sintomas"
                            value={email}
                            onChangeText={setSintomas}
                            numberOfLines={4}

                        />
                    </View>
                    <View style={{ width: 150, display: 'flex', flexDirection: 'row', marginLeft: 60 }}>
                        <Pressable
                            style={styles.btn}
                            onPress={handleCita}
                        >
                            <Text >Agregar cita</Text>
                        </Pressable>
                        <Pressable
                            style={styles.btn}
                            onPress={handleVisible}
                        >
                            <Text >Cancelar</Text>
                        </Pressable>
                    </View>

                </View>
            </ScrollView>
        </SafeAreaView>
    );
};
export default Form;

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'rgb(63,94,251)',
        marginTop: 30,
        paddingTop: 50,
        flex: 1
    },
    titulo: {
        fontSize: 30,
        fontFamily: 'sans-serif',
        fontStyle: 'italic',
        color: 'white',
        marginLeft:30
    },
    subtitilo: {
        fontSize: 30,
        fontStyle: 'italic',
        paddingBottom: 30,
        color: 'white',
    },
    viewPrincipal: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    btn: {
        backgroundColor: '#fff',
        padding: 15,
        marginTop: 30,
        marginBottom: 20,
        marginHorizontal: 20,
        borderRadius: 10,
    },
    btnText: {
        textAlign: 'center',

    },
    texto:{
        color:'white',fontSize:15,paddingBottom:3
    }
});