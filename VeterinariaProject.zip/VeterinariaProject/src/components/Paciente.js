import React,{useState} from "react";
import { SafeAreaView, View, Text } from "react-native";

function Paciente() {
    return(
        <SafeAreaView>
            <View>
                <Text>NOmbre paciente</Text>
                <Text>Fecha</Text>
            </View>
        </SafeAreaView>
    );
}