//import recta js
import React,{useState} from 'react';
//import iconos

import imgUser from '../img/user.png'
const Nabvar=()=>{
    //hook de estado
    const [isUserOpen, setIsUserOpen] = useState(false);

    //manejador de eventos
    const toggleUser = () => {
        setIsUserOpen(!isUserOpen);
    };

    return(
        <>
            <nav className="bg-white border-gray-200 dark:bg-gray-900 rounded ">
                <div className="max-w-screen-xl flex flex-wrap items-center justify-end mx-auto p-4">
  
                    <div className="relative inline-block" style={{ marginRight:'50px' }}>
                        <button
                            type="button"
                            className="flex  text-sm bg-gray-100 rounded-full md:mr-0 focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600 "
                            id="user-menu-button"
                            onClick={toggleUser}
                        >   
                            <img className="w-8 h-8 rounded-full" src={imgUser} alt="user img" />
                            <p className="p-2">Alejamundo</p> 
                            
                        </button>

                        {isUserOpen && (
                            <div
                            className="absolute z-50 mt-2 w-48 bg-white divide-y divide-gray-100 rounded-lg shadow dark:bg-gray-700 dark:divide-gray-600"
                            id="user-dropdown"
                            style={{ top: '100%', left: '0' }}
                            >
                                <div className="px-4 py-3">
                                    <span className="block text-sm text-gray-900 dark:text-white">Alejandra Orrego</span>
                                    <span className="block text-sm text-gray-500 truncate dark:text-gray-400">higuta47@gmail.com</span>
                                </div>
                                <ul className="py-2" ariaLabelledby="user-menu-button">
                                    <li>
                                    <a href="/home" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Cerrar sesión</a>
                                    </li>
                                </ul>
                            </div>
                        )}
                    </div>

                  
                 
                </div>
            </nav>
        </>
    );
}
export default Nabvar;