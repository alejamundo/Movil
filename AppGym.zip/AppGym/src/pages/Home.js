import React,{useState} from 'react';
// import { Link } from "react-router-dom";
import Sidebar from '../components/Sidebar';
import Nabvar from '../components/Navbar';
import Footer from '../components/Footer';
import { NavLink } from 'react-router-dom';

//import imagens 


const Home = () => {

    return ( 
    <>
        <Sidebar/>
        <div className=" sm:ml-64">
          
            <Nabvar/>
           
            <div className=" bg-white">
                <div className="mx-auto">
                    <div className="relative isolate overflow-hidden bg-[url('../img/metod.png')] bg-cover shadow-2xl lg:flex lg:gap-x-20 lg:px-24 lg:pt-0" style={{ opacity:0.8 }}>
                        <div className="mx-auto max-w-md text-center lg:mx-0 lg:flex-auto lg:py-32 lg:text-left">
                            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Somos un santuario de fuerza <br />y superación personal.</h2>
                            <p className="mt-6 text-lg leading-8 text-gray-300"> Únete a nosotros y descubre la pasión, la determinación y la confianza que te llevarán más allá de tus límites.</p>
                            <div className="mt-10 flex items-center justify-center gap-x-6 lg:justify-start">
                                <NavLink className="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold dark:text-gray-900 shadow-sm hover:bg-gray-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"  end to="/register" >Inscribete</NavLink>

                                <NavLink className="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold dark:text-gray-900 shadow-sm hover:bg-gray-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"  end to="/register" >Metodología <span ariaHidden="true">→</span></NavLink>


                            
                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>    
            <Footer/>    
        </div>
           

            {/* encabezado */}
            {/* <section className="bg-white dark:bg-gray-900">
                <div className="py-8 px-4 mx-auto max-w-screen-xl text-center lg:py-16">
                
                        <h1 className="mb-4 text-3xl font-semibold   tracking-tight leading-none text-dark-700 md:text-4xl lg:text-5xl dark:text-white">Bienvenido a EliteStrength Gym</h1>

                        <p className="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-16 lg:px-48 dark:text-gray-400">En nuestro gimnasio, no solo transformamos cuerpos, sino también vidas. Somos un santuario de fuerza y superación personal, donde los límites se desafían y se rompen, y los sueños se hacen realidad.</p>
                        <div className="flex flex-col space-y-4 sm:flex-row sm:justify-center sm:space-y-0 sm:space-x-4">
                            {/* <a href="l" className="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900">
                                Inscribete aquí &nbsp;
                                <i className="fa-solid fa-arrow-right "></i>
                            </a> */}
                           
                             
                        {/* </div>
                </div>
            </section>  */} 

            {/* Metodologia intro */}
            {/* <div role="status" class="bg-gray-50 space-y-8  md:space-y-0 md:space-x-8 md:flex md:items-center p-1">
                <div className="flex items-center justify-center w-full h-50 rounded sm:w-96  ">
                    <img className=" rounded w-screen  " src={imgMetodo} alt='img metodo' />  
                </div>

                <div className="w-full">
                   <p className='p-2'>
                   En nuestro gimnasio, creemos que cada persona tiene un potencial ilimitado esperando ser desbloqueado. Nuestra metodología "Alcanza tu Grandeza" se basa en la idea de que, sin importar dónde te encuentres en tu viaje de fitness, puedes superar tus límites y lograr resultados excepcionales. 
                   </p>
                </div>
                
            </div> */}


            
            {/* <h1 className="text-gray-600 font-light text-3xl p-4">Pagina de inicio</h1>
            <Link to="/plato" className=" bg-blue-500 hover:bg-blue-800 text-white p-3 rounded-full m-3">
                Pagina de inicio
            </Link> */}

       
    </>
      
    );
}

 
export default Home;