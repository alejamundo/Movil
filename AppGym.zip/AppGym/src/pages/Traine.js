
import React from "react";
const Traine=()=>{
    return(
        <>
        </>
    );
}
export default Traine;