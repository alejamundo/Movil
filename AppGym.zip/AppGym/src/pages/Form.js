import React from "react";
const Form = () => {
    // #manejador para resetear 
    const handleSubmit=(e)=>{
        alert('Datos Enviados Correctamente')
        e.preventDefault();
        e.target.reset();
    }
    return ( 
        <>
        <div className="p-4 sm:ml-64">
            <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
                <div className="  bg-gray-100 rounded-lg p-4">
                    <h2 className="text-2xl font-semibold">Agregar un plato</h2>
                    <form  className="mt-4" onSubmit={handleSubmit}>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Nombre del plato
                            </label>
                            <input
                                type="text"
                                name="nombre"  
                                className="border rounded w-full py-2 px-3"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Precio del plato
                            </label>
                            <input
                                type="number"
                                name="precio"
                                className="border rounded w-full py-2 px-3"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Categoría
                            </label>
                            <select
                                id="categoria"
                                name="categoria"
                                required
                                className="mt-1 p-2 border border-gray-300 rounded-md w-full focus:ring-blue-500 focus:border-blue-500"
                                >
                                <option value="">Selecciona una categoría</option>
                                <option value="Desayuno">Desayuno</option>
                                <option value="Almuerzo">Almuerzo</option>
                                <option value="Cena">Cena</option>
                                <option value="Bebidas">Bebidas</option>
                                <option value="Postres">Postres</option>
                            </select>
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Imagen
                            </label>
                            <input
                            type="file" // Cambiamos el tipo a "file"
                            id="imagen"
                            name="imagen"
                            required
                            accept="image/*" // Limitamos a tipos de archivo de imagen
                            className="mt-1 p-2 border border-gray-300 rounded-lg w-full focus:ring-blue-500 focus:border-blue-500"
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Descripción
                            </label>
                            <textarea
                                name="descripcion"
                                className="border rounded w-full py-2 px-3"
                                rows="4"
                                required
                            />
                        </div>
                        <button
                        type="submit"
                        className="bg-blue-500 hover:bg-blue-800 text-white py-2 px-4 rounded-full"
                        >
                        Agregar Plato
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </>
    )
       
}
 
export default Form;