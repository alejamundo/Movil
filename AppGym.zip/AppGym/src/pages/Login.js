import React from "react";
import { Link } from "react-router-dom";
import imgGym from '../img/gym.png'

const Menu = () => {
    return ( 
    <>

        <section className="bg-gray-50 dark:bg-gray-900 ">
            <div className="flex flex-col  items-center justify-center h-screen">

                <a href="/" className="flex flex-col justify-center items-center mb-6 font-semibold text-gray-900 dark:text-white ">
                    
                <img src={imgGym} alt="Icono gym" width={'80%'}/>
                  <span> EliteStrength Gym</span>    
                </a>

                <div className=" w-full md:w-1/2 bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
                    <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
                        <h1 className="text-xl text-center  font-bold leading-tight tracking-tight text-gray-900  dark:text-white">
                            Ingresa a tu Cuenta <i className="fa-solid fa-right-to-bracket"></i>
                        </h1>
                        <form className="space-y-4 md:space-y-6" action="#">
                            <div>
                                <label for="usuario" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Usuario</label>
                                <input type="usuario" name="usuario" id="usuario" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="alejamundo" required/>
                            </div>
                            <div>
                                <label for="password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Contraseña</label>
                                <input type="password" name="password" id="password" placeholder="••••••••" className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required/>
                            </div>
                           
                            <button type="submit" className="w-full text-white bg-blue-600 hover:bg-blue-400 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Ingresar</button>
                            <p className="text-sm font-light text-gray-500 dark:text-gray-400">
                               ¿Aún no tienes cuenta? 
                                <Link to="/register"className="font-medium text-primary-600 hover:underline dark:text-primary-500">
                                    Registrate
                                </Link>
                               
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        {/* <div className="">
            <h1 className="text-gray-600 font-light text-3xl p-4">Pagina Login</h1>
            <Link to="/plato" className=" bg-blue-500 hover:bg-blue-800 text-white p-3 rounded-full m-3">
                Pagina de inicio
            </Link>

        </div> */}
    </>
      
    );
}


 
export default Menu;