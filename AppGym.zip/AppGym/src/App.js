import React from 'react';
import './css/main.css';
import { Routes, Route } from 'react-router'; 
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Traine from './pages/Traine';
import Form from './pages/Form';


function App() {
  return (
    <div>
    <Routes>
      <Route path='/' element={<Login/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/home' element={<Home/>}/>
      <Route path='/trainer' element={<Traine/>}/>
      <Route path='/form' element={<Form/>}/>
    </Routes>
    </div>
  );
}

export default App;
