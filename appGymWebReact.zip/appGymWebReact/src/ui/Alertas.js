import Swal from "sweetalert2";


Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 5000,
});

export const showSuccessAlert = (message) => {
    Swal.fire({
        title: "Éxito",
        text: message,
        icon: "success",
    });
};
export const showErrorAlert = (message) => {
    Swal.fire({
      title: "Error",
      text: message,
      icon: "error",
    });
  };
