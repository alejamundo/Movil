// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
 apiKey: "AIzaSyDEWLSh5jACAOOjX3XXAdNvrhkUFFUUdq4",
  authDomain: "appgym-3e346.firebaseapp.com",
  projectId: "appgym-3e346",
  storageBucket: "appgym-3e346.appspot.com",
  messagingSenderId: "1098356614786",
  appId: "1:1098356614786:web:dca241e6330fdcd6ef769b",
  measurementId: "G-5BXS9RFSP7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export default firebaseConfig;