import React from "react";
import { Link } from "react-router-dom";
 
const Menu = () => {
    return ( 
    <>
        <div className="p-4 sm:ml-64">
            <h1 className="text-gray-600 font-light text-3xl p-4">Este es el Menú</h1>
            <Link to="/plato" className=" bg-blue-500 hover:bg-blue-800 text-white p-3 rounded-full m-3">
                Agregar un plato
            </Link>

        </div>
    </>
      
    );
}
 
export default Menu;