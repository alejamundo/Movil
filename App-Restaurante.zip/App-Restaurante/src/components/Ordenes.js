import React from "react";
const Ordenes = () => {
    return ( 
        <div className="p-4 sm:ml-64">
            <h1 className="text-gray-600 m-10 font-light text-3xl">Estas son las ordenes</h1>
        </div>
       
     );
}
 
export default Ordenes;