import React, { useContext } from "react";

import { useFormik, yupToFormErrors } from "formik";
import * as Yup from 'yup';
import { FirebaseContext } from "../firebase";
import { useNavigate } from "react-router";

const Plato = () => {
    const {firebase} =useContext(FirebaseContext);
    const navigate = useNavigate();
    //inicializar campos
    const formik =useFormik({
        initialValues:{
            nombre:'',
            precio:'',
            categoria:'',
            imagen:'',
            descripcion:''
        },
        //validación de los errores
        validationSchema:Yup.object({
            nombre: Yup.string()
                .min(4,'El nombre debe tener minimo 4 caraecteres')
                .required('El nombre es requerido'),
            
            precio: Yup.number()
                .min(4,'El valor minimo es 1')
                .required('El precio es  es requerido'),
            categoria: Yup.string()
                .required('Debe seleccionar una categoria'),
            descripcion: Yup.string()
                .min(4,'DEbetener minimo 2 caracteres')
                .required('La descripcion es obligatoria')


        }),
        onSubmit: plato=>{
            try{
                firebase.db.collection('producto').add(plato)
                console.log(plato)
                navigate('/menu');
            }
            catch(e){
                console.log(e)
            }
        }
    });

    // #manejador para resetear 
    // const handleSubmit=(e)=>{
    //     alert('Datos Enviados Correctamente')
    //     e.preventDefault();
    //     e.target.reset();
    // }
    return ( 
        <>
        <div className="p-4 sm:ml-64">
            <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
                <div className="  bg-gray-100 rounded-lg p-4">
                    <h2 className="text-2xl font-semibold">Agregar un plato</h2>
                    <form  className="mt-4" onSubmit={formik.handleSubmit}>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Nombre del plato
                            </label>
                            <input
                                type="text"
                                name="nombre"  
                                className="border rounded w-full py-2 px-3"
                                value={formik.values.nombre}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                        </div>
                        {/* validar  */}
                        {formik.touched.nombre && formik.errors.nombre ? (
                            <div>
                                <p className="text-red-800 font-bold">Ocurrio un error</p>
                                <p>{formik.errors.nombre}</p>
                            </div>
                        ):null}
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Precio del plato
                            </label>
                            <input
                                type="number"
                                name="precio"
                                className="border rounded w-full py-2 px-3"
                                value={formik.values.precio}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                        </div>
                        {formik.touched.precio && formik.errors.precio ? (
                            <div>
                                <p className="text-red-800 font-bold">Ocurrio un error</p>
                                <p>{formik.errors.precio}</p>
                            </div>
                        ):null}
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Categoría
                            </label>
                            <select
                                id="categoria"
                                name="categoria"
                                value={formik.values.categoria}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                                className="mt-1 p-2 border border-gray-300 rounded-md w-full focus:ring-blue-500 focus:border-blue-500"
                                >
                                <option value="">Selecciona una categoría</option>
                                <option value="Desayuno">Desayuno</option>
                                <option value="Almuerzo">Almuerzo</option>
                                <option value="Cena">Cena</option>
                                <option value="Bebidas">Bebidas</option>
                                <option value="Postres">Postres</option>
                            </select>
                        </div>
                        {formik.touched.categoria && formik.errors.categoria ? (
                            <div>
                                <p className="text-red-800 font-bold">Ocurrio un error</p>
                                <p>{formik.errors.categoria}</p>
                            </div>
                        ):null}
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Imagen
                            </label>
                            <input
                            type="file" // Cambiamos el tipo a "file"
                            id="imagen"
                            name="imagen"
                            value={formik.values.imagen}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            accept="image/*" // Limitamos a tipos de archivo de imagen
                            className="mt-1 p-2 border border-gray-300 rounded-lg w-full focus:ring-blue-500 focus:border-blue-500"
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Descripción
                            </label>
                            <textarea
                                id="descripcion"
                                name="descripcion"
                                className="border rounded w-full py-2 px-3"
                                rows="4"
                                value={formik.values.descripcion}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                            />
                        </div>
                        {formik.touched.descripcion && formik.errors.descripcion ? (
                            <div>
                                <p className="text-red-800 font-bold">Ocurrio un error</p>
                                <p>{formik.errors.descripcion}</p>
                            </div>
                        ):null}
                        <button
                        type="submit"
                        className="bg-blue-500 hover:bg-blue-800 text-white py-2 px-4 rounded-full"
                        >
                        Agregar Plato
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </>
    )
       
}
 
export default Plato;