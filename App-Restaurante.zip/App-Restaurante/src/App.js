import React from 'react';
import './css/main.css';
import { Routes, Route } from 'react-router'; 

import firebase,{FirebaseContext} from './firebase';

import Menu from './components/Menu';
import Ordenes from './components/Ordenes';
import Plato from './components/Plato';
import Sidebar from './ui/Sidebar';

function App() {
  return (
    <FirebaseContext.Provider
    
    value={{ firebase }}>
      <div>
        <Sidebar/>
          <Routes>
            <Route path='/' element={<Ordenes/>}/>
            <Route path='/menu' element={<Menu/>}/>
            <Route path='/plato' element={<Plato/>}/>
          </Routes>
      </div>
    </FirebaseContext.Provider>
   
  );
}

export default App;
