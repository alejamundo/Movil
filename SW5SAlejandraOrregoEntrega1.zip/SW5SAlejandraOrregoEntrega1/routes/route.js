import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import Home from "../src/Home/index";
import Login from "../src/Login/index";
import Register from "../src/Register/index";
import Consultas from "../src/Consultas/index";
import Principal from "../src/Principal/index";
import Novedades from "../src/Novedades/index";




const Stack = createNativeStackNavigator();
const MainStack = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Principal" component={Principal} />
        <Stack.Screen name="Consultas" component={Consultas} />
        <Stack.Screen name="Novedades" component={Novedades} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default MainStack;
