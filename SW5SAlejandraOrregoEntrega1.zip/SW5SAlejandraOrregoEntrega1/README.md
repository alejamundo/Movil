# SW5AlejandraOrregoEntrega1
Entregable número 1

# Mi Proyecto de React Native con Expo

Este es un proyecto de React Native desarrollado utilizando Expo. 

## Requisitos

- Node.js y npm (Node Package Manager) instalados en tu sistema.

## Cómo Ejecutar el Proyecto

1. **Clona el Repositorio:**
  
2. **Instala dependencias :**
npm install

3. **Inicia el Servidor de Desarrollo**

si tiene emulador android prendido ejecutar
** npm run android


si no tiene emulador 
** npm start
Esto abrirá una página en tu navegador con un código QR que puedes escanear usando la aplicación Expo Go en tu dispositivo móvil. También puedes presionar "w", "i" o "a" en la terminal para abrir la app en un simulador o emulador iOS, Android o web respectivamente.


Contacto
higuta47@gmail.com

¡Gracias!

