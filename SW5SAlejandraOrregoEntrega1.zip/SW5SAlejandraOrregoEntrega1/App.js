import MainStack from './routes/route';
import { UserProvider } from "./src/UserContext";
import { RecordsProvider } from "./src/RegistrosContext";

export default function App() {
  return (
    <UserProvider>
      <RecordsProvider>
        <MainStack />
      </RecordsProvider>
    </UserProvider>
  );
}


