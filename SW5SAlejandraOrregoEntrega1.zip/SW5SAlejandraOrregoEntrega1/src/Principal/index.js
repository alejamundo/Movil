import React, { useState, useContext } from "react";
import { RecordsContext } from '../RegistrosContext';
import {
  View,
  Text,
  SafeAreaView,
  Button,
  StyleSheet,
  ScrollView,
  Image,
  TextInput,
  Alert,
} from "react-native";

import DateTimePickerModal from "react-native-modal-datetime-picker";
import SelectDropdown from 'react-native-select-dropdown';
import imghomePage from "../../assets/principal.png";

export default function Principal({ navigation }) {
  // Javascript
  //Variables
  const ampm = ["Am", "Pm"];

  //Hooks
  const [DatePickerMostrar, setDatePickerMostrar] = useState(false);//
  const [showHoraFinalButton, setShowHoraFinalButton] = useState(false);
  const [day, setDay] = useState();
  const [startHour, setStartHour] = useState('');
  const [finalHour, setfinalHour] = useState('');
  const [startTimeZone, setStartTimeZone] = useState('');
  const [finalTimeZone, setfinalTimeZone] = useState('');
  const [totalHours, setTotalHours] = useState();

  //hoosk storage context
  const { addRecord } = useContext(RecordsContext);

  //Manejadores
  const showDatePicker = () => {
    setDatePickerMostrar(true);
  };
  const hideDatePicker = () => {
    setDatePickerMostrar(false);
  };
  const handleConfirm = (date) => {
    const selectedDate = new Date(date);
    setDay(selectedDate);
    hideDatePicker();
  };
  const handleHourChange = (text) => {
    const numericValue = parseInt(text);
    if (!isNaN(numericValue) && numericValue >= 1 && numericValue <= 12) {
      setStartHour(text);
    }
  };
  const handleHourFinal = (hourF) => {
    const numericValue = parseInt(hourF);
    if (!isNaN(numericValue) && numericValue >= 1 && numericValue <= 12) {
      setfinalHour(hourF);
    } else {
      setfinalHour('');
    }
  };
  const handleFinalDate = (option) => {
    setfinalTimeZone(option);
  };
  const handleRegisterClick = () => {
    if (day != '' && startHour != '' && startTimeZone != '') {
      //registrar datos y mostrar hora salida
      setShowHoraFinalButton(true);
    } else {
      Alert.alert(
        'Falta llenar campos',
        'Rellene cada uno de los campos',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  };
  const handleCalculator = () => {
    if (finalTimeZone != '' && finalHour != '') {
      // Convierte las horas AM/PM a formato de 24 horas
      const startHour24 = startTimeZone === 'Am' ? startHour : (parseInt(startHour) + 12);
      const finalHour24 = finalTimeZone === 'Am' ? finalHour : (parseInt(finalHour) + 12);
      var total = finalHour24 - startHour24;
      if (total < 0) {
        total += 24; // Ajustar el total si es negativo
      }
      setTotalHours(total);

    } else {
      Alert.alert(
        'Falta llenar datos de salida',
        'Rellene cada uno de los campos para poder calcular el total de horas laboradas',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  };
  const handleRegister = () => {
    if (totalHours) {
      //ya teniendo todos los datos usar el contexto para almacenar todos los datos de registro de horas
      addRecord(
        {
          day: day,
          startHour: startHour,
          startTimeZone: startTimeZone,
          finalHour: finalHour,
          finalTimeZone: finalTimeZone,
          totalHours: totalHours
        }
      );
      Alert.alert(
        'Registro exitoso',
        'se creo un registro exitoso',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      );

    } else {
      Alert.alert(
        'Faltan datos hora final',
        'Por favor rellene los campos faltantes y realize los calculos',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  }

  //Vista principal
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View>
          <View style={styles.titulo}>
            <Text style={{ fontSize: 25 }}>Registra horas laborales</Text>
          </View>

          <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>Ingrese la fecha actual:</Text>
          <Button title="Establezca la Fecha" onPress={showDatePicker} />
          <DateTimePickerModal
            isVisible={DatePickerMostrar}
            mode="date"
            onConfirm={handleConfirm}
            onCancel={hideDatePicker}

          />

          <Text style={{ fontSize: 15, paddingTop: 10, paddingBottom: 10, textAlign: 'center' }}>{day === undefined ? 'date' : day.toDateString()}</Text>
          <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>Ingrese la hora de inicio (1-12):</Text>

          <View style={styles.sectionStyle}>
            <TextInput
              style={{ textAlign: 'center' }}
              value={startHour}
              onChangeText={handleHourChange}
              keyboardType="numeric"
              maxLength={2} // Limitar la longitud del input a 2 caracteres
            />
          </View>

          <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>Seleccione AM/PM:</Text>
          <View style={styles.btn}>
            <SelectDropdown
              data={ampm}
              onSelect={(selectedItem) => {
                setStartTimeZone(selectedItem);
              }}
              defaultValue={startTimeZone}
            />
          </View>
          <Text></Text>
          <Button title="Registrar" color={"#07073e"} onPress={handleRegisterClick} style={{ Top: 20 }} />

          <Text></Text>
          <View >
            {showHoraFinalButton && (

              <TextInput
                style={styles.sectionStyle}
                placeholder='ingrese hora final'
                onChangeText={handleHourFinal}
                keyboardType="numeric"
                maxLength={2} // Limitar la longitud del input a 2 caracteres
                value={finalHour}
              />
            )}

            {showHoraFinalButton && (
              <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>Seleccione AM/PM:</Text>
            )}

            <View style={styles.btn}>
              {showHoraFinalButton && (

                <SelectDropdown
                  data={ampm}
                  onSelect={handleFinalDate}
                  defaultValue={finalTimeZone}
                />
              )}
            </View>

          </View>
          <View style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center' }}>
            {showHoraFinalButton && (

              <Button title="Calcular"
                onPress={handleCalculator}
                color={"#07073e"}>
              </Button>
            )}
            {showHoraFinalButton && (

              <Button title="Guardar registro"
                onPress={handleRegister}
                color={"green"}>
              </Button>
            )}

          </View>

          <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>Las horas laboradas son:</Text>
          <Text style={{ fontSize: 18, paddingBottom: 10, textAlign: 'center' }}>{totalHours}</Text>

          <View style={styles.login}>
            <Image source={imghomePage} />
          </View>
          <View style={styles.btn}>
            <Button
              title="Ingrese novedades"
              color="red"
              onPress={() => { navigation.navigate('Novedades') }}
            />
            <Button
              title="Realice consultas"
              color="green" 
              onPress={() => { navigation.navigate('Consultas') }}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}


//estilos pagina principal
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "10%",
    alignItems: "center",
    backgroundColor: "white",
    justifyContent: 'center',
  },
  titulo: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  btn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  sectionStyle: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 0.5,
    borderColor: "#000",
    height: 40,
    borderRadius: 5,
    margin: 10,
    textAlign: 'center',
  },


});

