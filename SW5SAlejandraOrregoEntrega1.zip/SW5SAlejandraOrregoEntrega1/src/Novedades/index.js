import React, { useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  Button,
  StyleSheet,
  Image,
  ScrollView,
  TextInput,
  Alert,
} from "react-native";
import novelty from "../../assets/novedades.png";
import DateTimePickerModal from "react-native-modal-datetime-picker";

export default function Novedades({ navigation }) {
  // Jevascript
  // hooks state
  const [DatePickerMostrar1, setDatePickerMostrar1] = useState(false);
  const [starDateInability, setStarDateInability] = useState(null);
  const [DatePickerMostrar2, setDatePickerMostrar2] = useState(false);
  const [finalDteInability, setFinalDateInability] = useState(null);
  const [daysInability, setDaysInability] = useState(null);

  //Hooks licencias
  const [HourLicense, setHourLicense] = useState('');
  const [result, setResult] = useState('');

  //Hook Vacaciones
  const [dayVacation, setDayVacation] = useState('');

  // Manejadores
  const showDatePicker1 = () => {
    setDatePickerMostrar1(true);
  };
  const hideDatePicker1 = () => {
    setDatePickerMostrar1(false);
  };
  const showDatePicker2 = () => {
    setDatePickerMostrar2(true);
  };
  const hideDatePicker2 = () => {
    setDatePickerMostrar2(false);
  };
  const handleStartInability = (date) => {
    // const selectedDate = new Date(date);
    setStarDateInability(date);
    hideDatePicker1();
  };

  const handleFinalInability = (date) => {
    // const selectedDate = new Date(date);
    setFinalDateInability(date);
    hideDatePicker2();
  };

  const calculatorDaysInability = () => {
    // console.log(starDateInability);
    if (starDateInability && finalDteInability) {
      const diferenceInTime = finalDteInability.getTime() - starDateInability.getTime();
      const daysInability = Math.ceil(diferenceInTime / (1000 * 60 * 60 * 24));
      setDaysInability(daysInability);
    } else {
      Alert.alert(
        'Faltan datos',
        'Por favor rellene los fechas faltantes',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  };

  //manejadores licencias
  const calculatorLicense = () => {
    if (HourLicense !== '') {
      const hour = parseFloat(HourLicense);

      if (!isNaN(hour)) {
        if (hour > 8) {
          setResult(`Vacaciones (${hour} horas)`);
        } else {
          setResult(`Licencia (${hour} horas)`);
        }
      } else {
        setResult('Por favor, ingresa un valor numérico válido.');
      }
    } else {
      setResult('Por favor, ingresa el número de horas.');
    }
  };

  //manejadores vacaciones
  const handleDaysVacation = (n) => {
    if (!isNaN(n)) {
      const number = parseInt(n);
      if (number >= 1 && number <= 15) {
        setDayVacation(n);
      }
    }
  };
  const hadleSaveNews = () => {
    if (starDateInability && finalDteInability && HourLicense && dayVacation && result) {
      Alert.alert(
        'Novedades registradas exitosamente!',
        'Licencias: ' + result + '\nVacaciones: ' + dayVacation + ' dias' + '\nIncapacidades: ' + daysInability + ' dias',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    } else {
      Alert.alert(
        'Faltan datos',
        'Por favor rellene los fechas faltantes y realice los calculos',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  }

  //visata novedades
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        {/* vista Incapacidades */}
        <View>
          <View style={styles.title}>
            <Text style={{ fontSize: 20, paddingBottom: 10 }}>Registro de Novedades</Text>
            <View style={styles.login}>
              <Image source={novelty} />
            </View>

            <Text style={{ fontSize: 22, paddingBottom: 10, textAlign: 'center' }}>Incapacidades</Text>
            <View style={{ display: 'flex', flexDirection: 'row', marginRight: 15 }}>
              <Button title="Ingrese fecha inicio" onPress={showDatePicker1} color={"green"} />
              <DateTimePickerModal
                isVisible={DatePickerMostrar1}
                mode="date"
                onConfirm={handleStartInability}
                onCancel={hideDatePicker1}
              />
              <Text></Text>
              <Button title="Ingrese fecha fin" onPress={showDatePicker2} color={"red"} />
              <DateTimePickerModal
                isVisible={DatePickerMostrar2}
                mode="date"
                onConfirm={handleFinalInability}
                onCancel={hideDatePicker2}
              />
            </View>
            <Text></Text>
            <Button title="Calcular días" onPress={calculatorDaysInability} color={"#07073e"} />
            {daysInability !== null && (
              <Text style={{ fontSize: 20 }}>Días de incapacidad: {daysInability}</Text>
            )}
          </View>
        </View>
        <View style={styles.hrSeparator} />
        {/* vista loicensias  */}
        <View>
          <View style={styles.title}>
            <Text style={{ fontSize: 22, paddingBottom: 10, textAlign: 'center' }}>Licencias</Text>
            <View style={styles.sectionStyle}>
              <TextInput
                placeholder="Ingrese horas de licencia"
                keyboardType="numeric"
                value={HourLicense}
                onChangeText={text => setHourLicense(text)}
                style={{ textAlign: 'center' }}
              />
            </View>

            <View />
            <Text></Text>
            <Button title="Calcular" onPress={calculatorLicense} color={"#07073e"} />
            {result !== null && (
              <Text style={{ fontSize: 18, textAlign: 'center' }}>La licencia cuenta como: {result}</Text>
            )}
          </View>
        </View>
        <View style={styles.hrSeparator} />
        {/* //vista vacaciones */}
        <View>
          <View style={styles.title}>
            <Text style={{ fontSize: 22, paddingBottom: 10, textAlign: 'center' }}>Vacaciones</Text>
            <View style={styles.sectionStyle}>
              <TextInput
                placeholder="Ingrese los dias de vacaciones"
                keyboardType="numeric"
                value={dayVacation}
                onChangeText={handleDaysVacation}
                style={{ textAlign: 'center' }}
              />
            </View>
          </View>
        </View>
        <Button title="Guardar novedades" onPress={hadleSaveNews} color={"#07073e"}></Button>
      </ScrollView>
    </SafeAreaView>
  );
}

//estilos para novedades
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "20%",
    alignItems: "center",
    backgroundColor: "white",
  },
  title: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 5,
    borderRadius: 10,
    overflow: 'hidden'
  },
  hrSeparator: {
    borderBottomWidth: 1,
    borderColor: "#ccc",
    marginVertical: 10,
  },
  sectionStyle: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 0.5,
    borderColor: "#000",
    height: 40,
    borderRadius: 5,
    margin: 10,
    textAlign: 'center',
  },
});
