import React, { useContext, useState } from "react";
import { RecordsContext } from '../RegistrosContext';
import {
  View,
  Text,
  SafeAreaView,
  Button,
  StyleSheet,
  Image,
  FlatList,
} from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import imgconsultation from "../../assets/consultas.png";
export default function Consultas({ navigation }) {
  //Javascript
  //variables
  const recordsPage = 10;

  //Hook de contexto
  const recordContext = useContext(RecordsContext);
  const record = recordContext.record;

  //Hook de estados
  const [page, setPage] = useState(1);
  const [startDate, setStartDate] = useState(null);
  const [finalDate, setFinalDate] = useState(null);
  // Estados para controlar los modales de los pickers-- fecha
  const [datePickerStartShow, setDatePickerStartShow] = useState(false);
  const [datePickerFinalShow, setDatePickerFinalShow] = useState(false);


  //manejadores
  const handleStartConfirm = (date) => {
    setStartDate(date);
    setDatePickerStartShow(false);
  };
  const handleFinalConfirm = (date) => {
    setFinalDate(date);
    setDatePickerFinalShow(false);
  };

  const hideDatePickerStart = () => {
    setDatePickerStartShow(false);
  };
  const showDatePickerStart = () => {
    setDatePickerStartShow(true);
  };
  const showDatePickerFinal = () => {
    setDatePickerFinalShow(true);
  };

  const hideDatePickerFinal = () => {
    setDatePickerFinalShow(false);
  };
  const filterDate = (record) => {
    if (startDate && finalDate) {
      const dateRecord = new Date(record.day);
      return dateRecord >= startDate && dateRecord <= finalDate;
    }
    return true;
  };
  const filterRecords = record.filter(filterDate);
  const paginatedRegister = filterRecords.slice(
    (page - 1) * recordsPage,
    page * recordsPage
  );
  const onPageChange = (newPage) => {
    setPage(newPage);
  };

  const RecordCard = ({ record }) => {
    return (
      <View style={styles.card}>
        <Text>Fecha: {record.day.toDateString()}</Text>
        <Text>Hora Inicio: {record.startHour}</Text>
        <Text>Zona Horaria Inicio: {record.startTimeZone}</Text>
        <Text>Hora Final: {record.finalHour}</Text>
        <Text>Zona Horaria Final: {record.finalTimeZone}</Text>
        <Text>Total de horas trabajadas: {record.totalHours} horas</Text>
      </View>
    );
  };

  console.log(filterRecords);
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <View style={styles.title}>
          <Text style={{ fontSize: 20 }}>Registros almacenados</Text>

          <View style={styles.login}>
            <Image source={imgconsultation} />
          </View>

          <Text style={{ fontSize: 15, paddingBottom: 10 }}>Filtre los registros por fecha</Text>
          {/* Selector de fecha de inicio */}
          <Button title="Seleccionar Fecha de Inicio" onPress={showDatePickerStart} color={"#07073e"} />
          <DateTimePickerModal
            isVisible={datePickerStartShow}
            mode="date"
            onConfirm={handleStartConfirm}
            onCancel={hideDatePickerStart}
          />
          <Text></Text>

          {/* Selector de fecha de fin */}
          <Button title="Seleccionar Fecha de Fin" onPress={showDatePickerFinal} color={"#07073e"} />
          <DateTimePickerModal
            isVisible={datePickerFinalShow}
            mode="date"
            onConfirm={handleFinalConfirm}
            onCancel={hideDatePickerFinal}
          />
          <Text></Text>

          <FlatList
            data={paginatedRegister}
            renderItem={({ item }) => <RecordCard record={item} />}
            keyExtractor={(item, index) => index.toString()}
          />
          <View style={styles.pagination}>
            <Button
              title="Anterior"
              disabled={page === 1}
              onPress={() => onPageChange(page - 1)}
              color={"#07073e"}
            />
            <Text>Página {page}</Text>
            <Button
              title="Siguiente"
              disabled={paginatedRegister.length < recordsPage}
              onPress={() => onPageChange(page + 1)}
              color={"#07073e"}
            />
          </View>
        </View>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "20%",
    alignItems: "center",
    backgroundColor: "white",
  },
  title: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  card: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    marginBottom: 10,
    borderRadius: 10,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  btn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },

});
