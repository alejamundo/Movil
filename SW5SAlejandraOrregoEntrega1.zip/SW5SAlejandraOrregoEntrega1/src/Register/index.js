import React, { useState, useContext } from "react";
import { UserContext } from '../UserContext';
import {
  View,
  Text,
  TextInput,
  SafeAreaView,
  Button,
  StyleSheet,
  Image,
  ScrollView,
  Alert,
} from "react-native";
import register from "../../assets/registro.png";


export default function Register({ navigation }) {
  //Javascript
  //variables 
  const pswdPatron = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.#])[A-Za-z\d@$!%*?&.#]{8}$/;

  //Hooks estados
  const [name, setName] = useState("");
  const [user, setUser] = useState("");
  const [pswd, setPswd] = useState("");

  //Hooks contexto storage
  const { addUser } = useContext(UserContext);

  //Manejadores texto
  const handleChangeTextName = (inputName) => {
    const filterName = inputName.replace(/[^a-zA-Z\s]/g, "");
    setName(filterName);
  };
  const handleChangeTextUser = (inputUser) => {
    setUser(inputUser);
  }
  const handleChangeTextPswd = (inputPswd) => {
    setPswd(inputPswd);
  };

  //Manejadores button
  const handleOnPressRegister = () => {

    if (name && user) {
      if (pswdPatron.test(pswd)) {
        //si los campos estan llenos y la contraseña es correcta
        addUser({ name: name, user: user, pswd: pswd })
        Alert.alert(
          'Exito!',
          'Usuario Registrado correctamente!'
        );
        navigation.navigate('Login');
      } else {
        Alert.alert(
          'Contraseña invalida',
          'La Contraseña debe tener 8 caracteres, 1 mayuscula, 1 minuscula, 1 número y 1 caracter especial. ejemplo: Aleja.12',
          [{ text: 'Cancelar' }, { text: 'Aceptar' }],
          { cancelable: false }
        );
      }
    } else {
      Alert.alert(
        'Faltan datos para el registro',
        'Por favor, completa todos los campos para continuar.',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false } // Evita que se cierre al tocar fuera de la alerta
      );
    }
  }

  //vista registro
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View>
          <View style={styles.title}>
            <Text style={{ fontSize: 30 }}>Registrate</Text>
          </View>
          <View style={styles.login}>
            <Image source={register} />
          </View>
          <View style={styles.sectionStyle}>
            <Image
              source={{
                uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/input_username.png",
              }}
              style={styles.imageStyle}
            />
            <TextInput
              style={{ flex: 1 }}
              placeholder="Ingrese su nombre aquí"
              underlineColorAndroid="transparent"
              onChangeText={handleChangeTextName}
              value={name}
            />
          </View>

          <View style={styles.sectionStyle}>
            <Image
              source={{
                uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/input_username.png",
              }}
              style={styles.imageStyle}
            />
            <TextInput
              style={{ flex: 1 }}
              placeholder="Ingrese su usuario aquí"
              underlineColorAndroid="transparent"
              onChangeText={handleChangeTextUser}
              value={user}
            />
          </View>

          <View style={styles.sectionStyle}>
            <Image
              source={{
                uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/input_username.png",
              }}
              style={styles.imageStyle}
            />
            <TextInput
              style={{ flex: 1 }}
              placeholder="Ingrese su contraseña aquí"
              underlineColorAndroid="transparent"
              secureTextEntry={true}
              onChangeText={handleChangeTextPswd}
              value={pswd}
            />
          </View>
          <Text
            style={{
              paddingLeft: 10,
              color: "red",
              paddingBottom: 10,
              fontSize: 15,
              paddingRight: 10,
              textAlign: "center",
            }}
          >
            Contraseña valida de 8 caracteres, debe tener: 1 mayuscula, 1
            minuscula, 1 número y 1 caracter especial.
          </Text>

          <Button title="Registrar" color={"#07073e"} onPress={handleOnPressRegister} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

//Estilos de registro
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "8%",
    alignItems: "center",
    backgroundColor: "white",
  },
  title: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  sectionStyle: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 0.5,
    borderColor: "#000",
    height: 40,
    borderRadius: 5,
    margin: 5,
  },
  imageStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: "stretch",
    alignItems: "center",
  },
});
