import React from "react";
import {
  View,
  Text,
  SafeAreaView,
  Button,
  StyleSheet,
  Image,
  ScrollView,
} from "react-native";
import home from "../../assets/home.png";

export default function Home({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View>
          <View style={styles.title}>
            <Text style={{ fontSize: 50 }}>Bienvenido!</Text>
            <Text style={{ fontSize: 20 }}>Sistema de registro de horas</Text>
          </View>
          <View style={styles.login}>
            <Image source={home} />
          </View>
          <View>
            <Button
              title="Inicia sesión"
              color={"#07073e"}
              onPress={() => {
                navigation.navigate("Login");
              }}
            />
            <Text></Text>
            <Button
              title="Registrar"
              color={"#07073e"}
              onPress={() => {
                navigation.navigate("Register");
              }}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "20%",
    alignItems: "center",
    backgroundColor: "white",
  },
  title: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "10%",
  },
});
