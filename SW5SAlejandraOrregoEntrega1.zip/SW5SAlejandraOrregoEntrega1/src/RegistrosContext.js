import React, { createContext, useState } from 'react';


export const RecordsContext = createContext();


export const RecordsProvider = ({ children }) => {
  const [record, setRecord] = useState([]);

  const addRecord = (newRecord) => {
    setRecord([...record, newRecord]);
  };

  return (
    <RecordsContext.Provider value={{ record, addRecord }}>
      {children}
    </RecordsContext.Provider>
  );
};
