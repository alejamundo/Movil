import React, { useContext, useState } from "react";
import { UserContext } from '../UserContext';
import {
  View,
  Text,
  TextInput,
  SafeAreaView,
  Button,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";

import login from "../../assets/icon.png";

export default function Login({ navigation }) {
  //Javascript
  //Hook de contexto
  const userContext = useContext(UserContext);
  const user = userContext.user;

  //Hook de estados
  const [userL, setUser] = useState("");
  const [pswdL, setPswd] = useState("");
  const userFind = user.find((user) => user.user === userL && user.pswd === pswdL);

  //Manejadores
  const handleOnpressEnter = () => {
    if (userFind) {
      navigation.navigate('Principal');
    } else {
      Alert.alert(
        'Inicio se sesión invalido',
        'si aún no tiene una cuenta ¡Registrate!',
        [{ text: 'Cancelar' }, { text: 'Aceptar' }],
        { cancelable: false }
      )
    }
  }
  const handleChangeTextUser = (inputUser) => {
    setUser(inputUser);
  }
  const handleChangeTextPswd = (inputPswd) => {
    setPswd(inputPswd);
  };

  //vista Login
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View>
          <View style={styles.titulo}>
            <Text style={{ fontSize: 30 }}>Inicia sesión</Text>
          </View>
          <View style={styles.login}>
            <Text
              style={{
                paddingBottom: "5%",
                fontSize: 20,
                color: "gray",
                fontWeight: "bold",
              }}
            >
              Login
            </Text>
            <Image source={login} />
          </View>
          <View style={styles.sectionStyle}>
            <Image
              source={{
                uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/input_username.png",
              }}
              style={styles.imageStyle}
            />
            <TextInput
              style={{ flex: 1 }}
              placeholder="Ingrese su usuario aquí"
              underlineColorAndroid="transparent"
              onChangeText={handleChangeTextUser}
              value={userL}

            />
          </View>

          <View style={styles.sectionStyle}>
            <Image
              source={{
                uri: "https://raw.githubusercontent.com/AboutReact/sampleresource/master/input_username.png",
              }}
              style={styles.imageStyle}
            />
            <TextInput
              style={{ flex: 1 }}
              placeholder="Ingrese su contraseña aquí"
              underlineColorAndroid="transparent"
              secureTextEntry={true}
              onChangeText={handleChangeTextPswd}
              value={pswdL}

            />
          </View>
          <View style={styles.login}>
            <Text>¿Aún no esta registrado?</Text>

            <TouchableOpacity>
              <Text style={{ color: "blue", textDecorationLine: "underline" }}
                onPress={() => { navigation.navigate('Register') }}>
                Registrate
              </Text>
            </TouchableOpacity>
          </View>
          <Button title="Ingresar"
            color={"#07073e"}
            onPress={handleOnpressEnter}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};


//Estilos componente login
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: "8%",
    alignItems: "center",
    backgroundColor: "white",
  },
  titulo: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  login: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: "5%",
  },
  sectionStyle: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 0.5,
    borderColor: "#000",
    height: 40,
    borderRadius: 5,
    margin: 10,
  },
  imageStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: "stretch",
    alignItems: "center",
  },
});
