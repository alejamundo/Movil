import React, { useState } from "react";
import { Link } from "react-router-dom";
import logo from "../img/gym.png";
import {
  RiDashboardLine,
  RiBriefcaseLine,
  RiCalendar2Line,
  RiMessage2Line,
  RiArrowDownSLine,
  RiMenu3Fill,
  RiCloseLine,

} from "react-icons/ri";

function Sidebar() {
  const [sidebar, setSidebar] = useState(false);

  const handleSidebar = () => {
    setSidebar(!sidebar);
  };

  return (
    <div >
      <div
        className={`fixed lg:static w-[80%] md:w-[40%] lg:w-full top-0 z-50 bg-white transition-all ${sidebar ? "left-0" : "-left-full"} h-full overflow-y-auto col-span-1 p-8 border-r`}
      >
        <div className="text-center p-8">
          <h1 className="uppercase font-bold tracking-[4px]">
            <img src={logo} alt="logo img" />
            PowerFit
          </h1>
        </div>
        <div className="flex flex-col justify-between h-[750px]">
          <nav>
            <ul>
              <li>
                <Link
                  to="/"
                  className="flex items-center gap-4 hover:bg-purple-600 p-4 text-gray-400 hover:text-white rounded-lg transition-colors font-semibold"
                >
                  <RiDashboardLine /> Home
                </Link>
              </li>
              <li>
                <Link
                  to="/register"
                  className="flex items-center gap-4 hover:bg-purple-600 p-4 text-gray-400 hover:text-white rounded-lg transition-colors font-semibold"
                >
                  <RiBriefcaseLine /> Registrar
                </Link>
              </li>
              <li>
                <Link
                  to="/training"
                  className="flex items-center gap-4 hover:bg-purple-600 p-4 text-gray-400 hover:text-white rounded-lg transition-colors font-semibold"
                >
                   <RiDashboardLine /> Entrenamientos
                </Link>
              </li>
              <li>
                <Link
                  to="/assign"
                  className="flex items-center gap-4 hover:bg-purple-600 p-4 text-gray-400 hover:text-white rounded-lg transition-colors font-semibold"
                >
                  <RiMessage2Line /> Asignaciones
                </Link>
              </li>
              <li>
                <Link
                  to="/admin"
                  className="flex items-center gap-4 hover:bg-purple-600 p-4 text-gray-400 hover:text-white rounded-lg transition-colors font-semibold"
                >
                  <RiArrowDownSLine /> Admin Usuarios
                </Link>
              </li>
              
            </ul>
          </nav>
         
        </div>
      </div>
      <button
        onClick={handleSidebar}
        className="block lg:hidden fixed bottom-4 right-4 bg-purple-600 p-2 text-white rounded-full text-2xl z-40"
      >
        {sidebar ? <RiCloseLine /> : <RiMenu3Fill />}
      </button>
      
    </div>
  );
}

export default Sidebar;
