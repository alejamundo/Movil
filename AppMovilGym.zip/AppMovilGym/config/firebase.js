import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyC8Lz0T0fuppMprFvyIKoa2Ao8eNYqGyxQ",
  authDomain: "gymaleja-640ba.firebaseapp.com",
  projectId: "gymaleja-640ba",
  storageBucket: "gymaleja-640ba.appspot.com",
  messagingSenderId: "551189760069",
  appId: "1:551189760069:web:8bdf4aadea43015143fb2c",
  measurementId: "G-XEFXT236W0"
};
// initialize firebase
initializeApp(firebaseConfig);
export const db = getFirestore();
