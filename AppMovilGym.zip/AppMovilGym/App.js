import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import logo from './assets/gym.png';
import { View,Image } from "react-native";
import Login from "./screens/Login";
import Home from "./screens/Home";
// import Signup from "./screens/Signup";
// import Chat from "./screens/Chat";

const Stack = createStackNavigator();

export default function App() {
  // Configuración de la navegación de la app
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerTitle: "PowerFit",
          headerTitleStyle: {
            fontWeight: "bold",
            fontSize: 24,
          },
          headerTitleAlign: "center",
          headerLeft: () => (
            <Image
              source={ logo } 
              style={{ width: 60, height: 40, marginLeft: 10 }}
            />
          ),
        }}
      >
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Home" component={Home} />
        {/* <Stack.Screen name="Chat" component={Chat} />
        <Stack.Screen name="Signup" component={Signup} /> */}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
