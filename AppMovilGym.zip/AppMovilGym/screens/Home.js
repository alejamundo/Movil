import React, { useEffect, useState } from "react";
import { View, TouchableOpacity, Text, Image, StyleSheet } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { FontAwesome5 } from "@expo/vector-icons";
import { ScrollView } from "react-native-gesture-handler";
import { db } from "../config/firebase";
import {
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";
const imgTraining = require("../assets/training.jpg");

const Home = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const userId = route.params?.userId;

  const [assignedData, setAssignedData] = useState([]);

  // Función para obtener datos de "assigned" y relacionarlos con "training"
  const getAssignedDataFromDatabase = async (userId) => {
    try {
      const assignedCollection = collection(db, "assigned");
      const q = query(assignedCollection, where("userId", "==", userId));
      const querySnapshot = await getDocs(q);

      const assignedData = [];
      for (const doc of querySnapshot.docs) {
        const data = doc.data();
        const trainingId = data.trainingId;

        // Ahora, consulta la colección "training" para obtener los datos de entrenamiento
        const trainingCollection = collection(db, "training");
        const trainingQuery = query(trainingCollection);
        const trainingQuerySnapshot = await getDocs(trainingQuery);

        trainingQuerySnapshot.forEach((trainingDoc) => {
          // Obtiene los datos de entrenamiento
          const trainingData = trainingDoc.data();

          // Compara el ID del entrenamiento en "assigned" con el ID en "training"
          if (trainingId === trainingDoc.id) {
            // Agrega los datos de entrenamiento a la estructura de datos de assigned
            data.trainingData = trainingData;
          }
        });

        assignedData.push(data);
      }

      return assignedData;
    } catch (error) {
      console.error("Error al obtener datos de la tabla 'assigned':", error);
      return [];
    }
  };

  useEffect(() => {
    if (userId) {
      // Verifica si userId está definido
      getAssignedDataFromDatabase(userId)
        .then((data) => {
          setAssignedData(data);
        })
        .catch((error) => {
          console.error("Error al obtener los registros de assigned:", error);
        });
    }
  }, [userId]);

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={{ fontSize:30, }}>Rutinas asignadas</Text>
        <Image source={imgTraining} alt="img trainig" style={styles.backImage}></Image>

        {assignedData.map((assignment, index) => (
          <View
            key={index}
            style={styles.assignmentCard}
          >
            <View style={styles.textContainer}>
              <Text style={styles.cardText}>
                <FontAwesome5 name="book" size={18} color="black" /> Categoría: {assignment.trainingData.category}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="calendar" size={18} color="black" /> Día: {assignment.trainingData.day}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="info-circle" size={18} color="black" /> Descripción: {assignment.trainingData.description}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="user" size={18} color="black" /> Nombre: {assignment.trainingData.name}
              </Text>
              <Text style={styles.cardText}>
                <FontAwesome5 name="clock" size={18} color="black" /> Hora de inicio: {assignment.trainingData.startHour}
              </Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

export default Home;

const styles = StyleSheet.create({
 container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  assignmentCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F6F7FB",
    padding: 10,
    marginBottom: 10,
    borderRadius:50,
    padding:20,
  },
  iconContainer: {
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  cardText: {
    fontSize: 16,
    marginBottom: 5,
  },
  backImage: {
    width: "100%",
    height: 200,
    position: "relative",
    top: 0,
    resizeMode: "cover",
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
});
